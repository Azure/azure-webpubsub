export const DEFAULT_ROOM_ID = "public" as const;
