"""Transport implementations for chat_service.

- self_host: native websockets server
- webpubsub: Azure Web PubSub service-backed
"""

__all__ = []

